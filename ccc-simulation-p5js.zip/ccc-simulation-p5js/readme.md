# How to Run

To run the following code

- Open Terminal
- Navigate to the folder containing the code (`cd 'directory'`)
- Run a python server in this directory (`python -m SimpleHTTPServer 8080` for python 2.7.x or `python -m http.server 8080` for python 3.x), where 8080 is the port the server will run on (you can use any non-reserved value)
- Open your web browser to http://localhost:8080/